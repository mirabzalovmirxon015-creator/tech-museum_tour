import PageHeader from "@/components/PageHeader";
import ResourceItem from "@/components/ResourceItem";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Lightbulb } from "lucide-react";

const sources = [
  {
    title: "Политехнический музей (официальный сайт)",
    description: "Официальный сайт Политехнического музея в Москве с информацией о выставках, экспонатах и образовательных программах.",
    url: "https://polymus.ru",
    type: "source" as const,
  },
  {
    title: "Министерство культуры Узбекистана",
    description: "Информация о музеях Узбекистана, включая Ташкентский Политехнический музей.",
    url: "https://madaniyat.uz",
    type: "source" as const,
  },
  {
    title: "Культура.РФ — Портал культурного наследия",
    description: "Российский портал о культуре с материалами о технических музеях страны.",
    url: "https://culture.ru",
    type: "source" as const,
  },
];

const articles = [
  {
    title: "История технических музеев",
    description: "Обзорная статья об истории развития технических музеев в России и странах СНГ.",
    type: "article" as const,
  },
  {
    title: "Развитие железнодорожного транспорта",
    description: "История паровозостроения и развития железных дорог в Российской империи и СССР.",
    type: "article" as const,
  },
  {
    title: "Космическая программа СССР",
    description: "Материалы о советской космической программе и её достижениях.",
    type: "article" as const,
  },
];

const additionalFacts = [
  "Политехнический музей Москвы был основан в 1872 году по инициативе Общества любителей естествознания",
  "Первый полёт человека в космос состоялся 12 апреля 1961 года",
  "Телеграф был изобретён Самуэлем Морзе в 1837 году",
  "Первый паровоз в России был построен в 1834 году Черепановыми",
  "Радиосвязь была изобретена Александром Поповым в 1895 году",
  "Первый искусственный спутник Земли был запущен СССР 4 октября 1957 года",
];

export default function ResourcesPage() {
  return (
    <div className="min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <PageHeader
          title="Материалы и источники"
          subtitle="Источники информации, использованные при создании проекта"
          badge="Ресурсы"
        />

        <div className="space-y-12">
          <section>
            <h2 className="text-2xl font-bold mb-6 opacity-0 animate-fade-in-left">
              Источники информации
            </h2>
            <div className="space-y-4">
              {sources.map((source, index) => (
                <ResourceItem key={index} {...source} index={index} />
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-6 opacity-0 animate-fade-in-left animation-delay-200">
              Дополнительные материалы
            </h2>
            <div className="space-y-4">
              {articles.map((article, index) => (
                <ResourceItem key={index} {...article} index={index + sources.length} />
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-6 opacity-0 animate-fade-in-left animation-delay-400">
              Интересные факты
            </h2>
            <Card className="neon-card rounded-md opacity-0 animate-fade-in-up animation-delay-500">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <div className="p-2 rounded-md bg-chart-4/20">
                    <Lightbulb className="w-5 h-5 text-chart-4" />
                  </div>
                  Знаете ли вы?
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4">
                  {additionalFacts.map((fact, index) => (
                    <li 
                      key={index} 
                      className="flex items-start gap-3 text-muted-foreground"
                    >
                      <span className="w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center flex-shrink-0 text-xs font-medium">
                        {index + 1}
                      </span>
                      {fact}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-6 opacity-0 animate-fade-in-left animation-delay-600">
              Благодарности
            </h2>
            <Card className="neon-card rounded-md opacity-0 animate-fade-in-up animation-delay-700">
              <CardContent className="p-6">
                <p className="text-muted-foreground">
                  Выражаем благодарность учителю русского языка и культуры речи за руководство 
                  проектом, а также музеям за предоставленные материалы и возможность 
                  познакомиться с историей технических достижений наших стран.
                </p>
              </CardContent>
            </Card>
          </section>
        </div>
      </div>
    </div>
  );
}
