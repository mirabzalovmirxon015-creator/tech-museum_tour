import PageHeader from "@/components/PageHeader";
import ExhibitCard from "@/components/ExhibitCard";
import locomotiveImage from "@assets/generated_images/steam_locomotive_museum_exhibit.png";
import telegraphImage from "@assets/generated_images/telegraph_communication_exhibit.png";
import spaceImage from "@assets/generated_images/soviet_space_technology_exhibit.png";
import clockImage from "@assets/generated_images/mechanical_clock_exhibit.png";
import radioImage from "@assets/generated_images/vintage_radio_tv_exhibit.png";
import aviationImage from "@assets/generated_images/aviation_engine_exhibit.png";

const exhibits = [
  {
    id: "locomotive",
    name: "Паровоз серии Ов",
    year: "1890-е",
    category: "Транспорт",
    description: "Один из первых массовых грузовых паровозов Российской империи. Эти локомотивы стали символом промышленной революции и сыграли важную роль в развитии железнодорожного транспорта.",
    facts: [
      "Производился на Путиловском заводе в Санкт-Петербурге",
      "Мог развивать скорость до 55 км/ч с грузовым составом",
      "Использовался более 50 лет на железных дорогах России и СССР",
      "Название 'Ов' означает 'Основной тип, вариант'"
    ],
    image: locomotiveImage,
    museum: "Политехнический музей",
  },
  {
    id: "telegraph",
    name: "Телеграфный аппарат Морзе",
    year: "1850-е",
    category: "Связь",
    description: "Оригинальный телеграфный аппарат системы Морзе, использовавшийся для передачи сообщений на дальние расстояния. Революционное изобретение, изменившее мир коммуникаций.",
    facts: [
      "Азбука Морзе используется и по сей день",
      "Первая телеграфная линия в России была открыта в 1852 году",
      "Телеграф работал со скоростью 20-30 слов в минуту",
      "Сообщения записывались на бумажную ленту точками и тире"
    ],
    image: telegraphImage,
    museum: "Ташкентский Политехнический музей",
  },
  {
    id: "space",
    name: "Модель спутника 'Восток'",
    year: "1961",
    category: "Космонавтика",
    description: "Масштабная модель космического корабля 'Восток', на котором Юрий Гагарин совершил первый в истории человечества полёт в космос 12 апреля 1961 года.",
    facts: [
      "Полёт Гагарина длился 108 минут",
      "Корабль 'Восток' весил 4,73 тонны",
      "Максимальная высота орбиты составила 327 км",
      "После полёта Гагарин стал всемирно известным героем"
    ],
    image: spaceImage,
    museum: "Политехнический музей",
  },
  {
    id: "clock",
    name: "Механические часы XVIII века",
    year: "1750-е",
    category: "Механика",
    description: "Уникальные механические часы с открытым механизмом, демонстрирующие мастерство часовых дел мастеров XVIII века. Сложная система шестерёнок и пружин обеспечивала точный ход.",
    facts: [
      "Изготовлены из латуни и стали вручную",
      "Требовали ежедневного завода",
      "Погрешность хода составляла несколько минут в сутки",
      "Являлись предметом роскоши и показателем статуса"
    ],
    image: clockImage,
    museum: "Ташкентский Политехнический музей",
  },
  {
    id: "radio",
    name: "Радиоприёмник 'Москвич'",
    year: "1950-е",
    category: "Радиоэлектроника",
    description: "Советский ламповый радиоприёмник, ставший символом послевоенной эпохи. Такие приёмники были в каждой советской семье и объединяли людей у радиоточки.",
    facts: [
      "Работал на радиолампах, а не транзисторах",
      "Принимал средние и длинные волны",
      "Корпус изготавливался из карболита или дерева",
      "Стоимость составляла около 30% месячной зарплаты"
    ],
    image: radioImage,
    museum: "Политехнический музей",
  },
  {
    id: "aviation",
    name: "Авиационный двигатель М-17",
    year: "1930-е",
    category: "Авиация",
    description: "Авиационный поршневой двигатель, устанавливавшийся на многие советские самолёты 1930-40-х годов. Надёжный и мощный мотор, обеспечивавший обороноспособность страны.",
    facts: [
      "Мощность составляла до 730 лошадиных сил",
      "Устанавливался на бомбардировщики ТБ-3",
      "Производился по лицензии немецкой компании BMW",
      "Выпускался на заводах в Рыбинске и Москве"
    ],
    image: aviationImage,
    museum: "Ташкентский Политехнический музей",
  },
];

export default function ExhibitsPage() {
  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <PageHeader
          title="Экспонаты музеев"
          subtitle="Уникальные технические экспонаты, рассказывающие историю научного прогресса"
          badge="Коллекция"
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {exhibits.map((exhibit, index) => (
            <ExhibitCard
              key={exhibit.id}
              {...exhibit}
              index={index}
            />
          ))}
        </div>

        <div className="mt-16 text-center opacity-0 animate-fade-in-up animation-delay-700">
          <p className="text-muted-foreground">
            Нажмите на любую карточку, чтобы узнать больше об экспонате
          </p>
        </div>
      </div>
    </div>
  );
}
