import { Link } from "wouter";
import HeroSection from "@/components/HeroSection";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Building2, Cpu, Users, BookOpen, ArrowRight } from "lucide-react";

const features = [
  {
    icon: Building2,
    title: "2 Музея",
    description: "Ташкентский Политехнический музей и Политехнический музей Москвы",
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    icon: Cpu,
    title: "6+ Экспонатов",
    description: "От паровых машин до космических технологий",
    color: "text-secondary",
    bgColor: "bg-secondary/10",
  },
  {
    icon: Users,
    title: "Наша команда",
    description: "Ученики 9 класса, создавшие этот проект",
    color: "text-accent",
    bgColor: "bg-accent/10",
  },
  {
    icon: BookOpen,
    title: "Материалы",
    description: "Источники и дополнительная информация",
    color: "text-chart-4",
    bgColor: "bg-chart-4/10",
  },
];

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <HeroSection />

      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4 opacity-0 animate-fade-in-up">
            Что вас ждёт
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto opacity-0 animate-fade-in-up animation-delay-100">
            Познакомьтесь с историей технических достижений двух великих стран
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card 
              key={index}
              className="neon-card overflow-visible text-center rounded-md opacity-0 animate-fade-in-up"
              style={{ animationDelay: `${200 + index * 100}ms`, animationFillMode: "forwards" }}
            >
              <CardContent className="p-6 space-y-4">
                <div className={`w-14 h-14 rounded-md ${feature.bgColor} flex items-center justify-center mx-auto`}>
                  <feature.icon className={`w-7 h-7 ${feature.color}`} />
                </div>
                <h3 className="font-semibold text-lg">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-card/30">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-6 opacity-0 animate-fade-in-up">
            О проекте
          </h2>
          <p className="text-lg text-muted-foreground mb-8 opacity-0 animate-fade-in-up animation-delay-100">
            Этот сайт создан в рамках СОР №2 по предмету «Русский язык и культура речи» 
            для учащихся 9 класса. Цель проекта — создать виртуальную экскурсию 
            по техническим музеям Узбекистана и России, познакомить с историей 
            развития науки и техники в наших странах.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 opacity-0 animate-fade-in-up animation-delay-200">
            <Link href="/museums">
              <Button size="lg" className="group">
                Исследовать музеи
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <Link href="/team">
              <Button size="lg" variant="outline">
                Узнать о команде
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
