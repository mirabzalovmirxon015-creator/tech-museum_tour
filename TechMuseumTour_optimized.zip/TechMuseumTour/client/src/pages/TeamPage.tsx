import PageHeader from "@/components/PageHeader";
import TeamMemberCard from "@/components/TeamMemberCard";
import { Card, CardContent } from "@/components/ui/card";
import { Target, BookOpen, Palette, Code } from "lucide-react";

const teamMembers = [
  {
    name: "Ученик 1",
    role: "Руководитель проекта",
    initials: "У1",
    color: "primary",
  },
  {
    name: "Ученик 2",
    role: "Исследователь",
    initials: "У2",
    color: "secondary",
  },
  {
    name: "Ученик 3",
    role: "Дизайнер",
    initials: "У3",
    color: "accent",
  },
  {
    name: "Ученик 4",
    role: "Контент-менеджер",
    initials: "У4",
    color: "primary",
  },
];

const roles = [
  {
    icon: Target,
    title: "Руководитель проекта",
    description: "Координация работы команды, планирование этапов проекта, контроль сроков выполнения",
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    icon: BookOpen,
    title: "Исследователь",
    description: "Сбор и анализ информации о музеях и экспонатах, проверка фактов",
    color: "text-secondary",
    bgColor: "bg-secondary/10",
  },
  {
    icon: Palette,
    title: "Дизайнер",
    description: "Разработка визуального оформления, подбор изображений и цветовой схемы",
    color: "text-accent",
    bgColor: "bg-accent/10",
  },
  {
    icon: Code,
    title: "Контент-менеджер",
    description: "Написание текстов, редактирование материалов, наполнение сайта контентом",
    color: "text-chart-4",
    bgColor: "bg-chart-4/10",
  },
];

export default function TeamPage() {
  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <PageHeader
          title="Наша команда"
          subtitle="Ученики 9 класса, создавшие этот проект для СОР №2 по РКИ"
          badge="Команда проекта"
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {teamMembers.map((member, index) => (
            <TeamMemberCard
              key={index}
              {...member}
              index={index}
            />
          ))}
        </div>

        <div className="space-y-12">
          <section>
            <h2 className="text-2xl font-bold mb-6 text-center opacity-0 animate-fade-in-up animation-delay-500">
              Роли в команде
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {roles.map((role, index) => (
                <Card 
                  key={index}
                  className="neon-card overflow-visible rounded-md opacity-0 animate-fade-in-up"
                  style={{ animationDelay: `${600 + index * 100}ms`, animationFillMode: "forwards" }}
                >
                  <CardContent className="p-6 flex items-start gap-4">
                    <div className={`p-3 rounded-md ${role.bgColor} flex-shrink-0`}>
                      <role.icon className={`w-6 h-6 ${role.color}`} />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-1">{role.title}</h3>
                      <p className="text-sm text-muted-foreground">{role.description}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          <section>
            <Card className="neon-card rounded-md opacity-0 animate-fade-in-up animation-delay-800">
              <CardContent className="p-8 text-center">
                <h3 className="text-xl font-bold mb-4 gradient-text">О нашей работе</h3>
                <p className="text-muted-foreground max-w-2xl mx-auto">
                  Наша команда работала над этим проектом в течение нескольких недель. 
                  Мы исследовали историю технических музеев, изучали экспонаты, 
                  собирали интересные факты и создавали современный интерактивный сайт. 
                  Этот проект помог нам не только улучшить навыки работы с информацией, 
                  но и узнать много нового о техническом наследии наших стран.
                </p>
              </CardContent>
            </Card>
          </section>
        </div>
      </div>
    </div>
  );
}
