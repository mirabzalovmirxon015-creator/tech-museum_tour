import PageHeader from "@/components/PageHeader";
import MuseumCard from "@/components/MuseumCard";
import tashkentMuseum from "@assets/generated_images/tashkent_polytechnic_museum_exterior.png";
import russianMuseum from "@assets/generated_images/russian_technical_museum_interior.png";

const museums = [
  {
    id: "tashkent",
    name: "Ташкентский Политехнический музей",
    location: "Ташкент",
    country: "Узбекистан",
    description: "Крупнейший технический музей Центральной Азии, основанный в 1971 году. Музей представляет богатую коллекцию экспонатов, отражающих историю развития науки и техники в регионе. Здесь можно увидеть образцы промышленного оборудования, транспорта, средств связи и космических технологий.",
    image: tashkentMuseum,
    founded: "1971",
    highlights: ["Космические технологии", "Транспорт", "Энергетика", "Связь"],
  },
  {
    id: "polytechnic",
    name: "Политехнический музей",
    location: "Москва",
    country: "Россия",
    description: "Один из крупнейших и старейших научно-технических музеев мира, основанный в 1872 году. Коллекция музея насчитывает более 200 000 экспонатов, охватывающих различные области науки и техники: от горного дела и металлургии до космонавтики и компьютерных технологий.",
    image: russianMuseum,
    founded: "1872",
    highlights: ["История техники", "Космонавтика", "Радиоэлектроника", "Автомобили"],
  },
];

export default function MuseumsPage() {
  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <PageHeader
          title="Технические музеи"
          subtitle="Исследуйте богатую историю технических достижений в музеях Узбекистана и России"
          badge="Музеи мира"
        />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {museums.map((museum, index) => (
            <MuseumCard
              key={museum.id}
              {...museum}
              index={index}
            />
          ))}
        </div>

        <div className="mt-16 p-8 rounded-md neon-card opacity-0 animate-fade-in-up animation-delay-500">
          <h2 className="text-2xl font-bold mb-4 gradient-text">Интересные факты о музеях</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold text-primary mb-2">Ташкентский Политехнический музей</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  Музей расположен в историческом здании в центре Ташкента
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  Коллекция включает уникальные экспонаты советской эпохи
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  Проводятся образовательные программы для школьников
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold text-secondary mb-2">Политехнический музей Москвы</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-secondary">•</span>
                  Входит в топ-10 научно-технических музеев мира
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-secondary">•</span>
                  Хранит первый советский компьютер и автомобиль
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-secondary">•</span>
                  Ежегодно принимает более 500 000 посетителей
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
