import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Calendar, Info, X } from "lucide-react";

interface ExhibitCardProps {
  id: string;
  name: string;
  year?: string;
  category: string;
  description: string;
  facts: string[];
  image: string;
  museum: string;
  index?: number;
}

export default function ExhibitCard({
  id,
  name,
  year,
  category,
  description,
  facts,
  image,
  museum,
  index = 0,
}: ExhibitCardProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <Card 
        className="group neon-card overflow-visible rounded-md cursor-pointer opacity-0 animate-fade-in-up"
        style={{ animationDelay: `${index * 100}ms`, animationFillMode: "forwards" }}
        onClick={() => setIsOpen(true)}
        data-testid={`card-exhibit-${id}`}
      >
        <div className="relative overflow-hidden rounded-t-md">
          <div className="aspect-[4/3]">
            <img
              src={image}
              alt={name}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          <div className="absolute bottom-4 left-4 right-4 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-2 group-hover:translate-y-0">
            <Button size="sm" variant="secondary" className="w-full backdrop-blur-sm">
              <Info className="w-4 h-4 mr-2" />
              Узнать больше
            </Button>
          </div>
        </div>

        <CardContent className="p-4 space-y-3">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors">
              {name}
            </h3>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="secondary" className="text-xs">
              {category}
            </Badge>
            {year && (
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Calendar className="w-3 h-3" />
                <span>{year}</span>
              </div>
            )}
          </div>

          <p className="text-sm text-muted-foreground line-clamp-2">
            {description}
          </p>
        </CardContent>
      </Card>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl gradient-text">{name}</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              {museum} {year && `• ${year}`}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            <div className="relative overflow-hidden rounded-md">
              <img
                src={image}
                alt={name}
                className="w-full h-64 object-cover"
              />
              <Badge className="absolute top-4 right-4 bg-primary/90">
                {category}
              </Badge>
            </div>

            <div>
              <h4 className="font-semibold mb-2">Описание</h4>
              <p className="text-muted-foreground">{description}</p>
            </div>

            {facts.length > 0 && (
              <div>
                <h4 className="font-semibold mb-3">Интересные факты</h4>
                <ul className="space-y-2">
                  {facts.map((fact, i) => (
                    <li 
                      key={i} 
                      className="flex items-start gap-3 text-sm text-muted-foreground"
                    >
                      <span className="w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center flex-shrink-0 text-xs font-medium">
                        {i + 1}
                      </span>
                      {fact}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
