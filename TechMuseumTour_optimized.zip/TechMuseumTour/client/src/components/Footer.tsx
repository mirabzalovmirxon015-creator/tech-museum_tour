import { Link } from "wouter";
import { Building2, Heart } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-card/50 border-t border-border/50 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2 group">
              <div className="p-2 rounded-md bg-primary/10 group-hover:bg-primary/20 transition-colors">
                <Building2 className="w-5 h-5 text-primary" />
              </div>
              <span className="font-semibold text-lg">ТехМузеи</span>
            </Link>
            <p className="text-sm text-muted-foreground">
              Виртуальная экскурсия по техническим музеям Узбекистана и России. 
              Школьный проект РКИ 9 класс.
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Навигация</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="/" className="hover:text-primary transition-colors">
                  Главная
                </Link>
              </li>
              <li>
                <Link href="/museums" className="hover:text-primary transition-colors">
                  Музеи
                </Link>
              </li>
              <li>
                <Link href="/exhibits" className="hover:text-primary transition-colors">
                  Экспонаты
                </Link>
              </li>
              <li>
                <Link href="/resources" className="hover:text-primary transition-colors">
                  Материалы
                </Link>
              </li>
              <li>
                <Link href="/team" className="hover:text-primary transition-colors">
                  Команда
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">О проекте</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>СОР №2 по РКИ</li>
              <li>9 класс</li>
              <li>2024 год</li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border/50 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <p>© 2024 Виртуальная экскурсия по техническим музеям</p>
          <p className="flex items-center gap-1">
            Сделано с <Heart className="w-4 h-4 text-accent fill-accent" /> для школьного проекта
          </p>
        </div>
      </div>
    </footer>
  );
}
