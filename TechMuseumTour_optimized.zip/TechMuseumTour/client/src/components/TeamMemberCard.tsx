import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface TeamMemberCardProps {
  name: string;
  role: string;
  initials: string;
  color?: string;
  index?: number;
}

export default function TeamMemberCard({
  name,
  role,
  initials,
  color = "primary",
  index = 0,
}: TeamMemberCardProps) {
  const colorClasses: Record<string, string> = {
    primary: "bg-primary/20 text-primary",
    secondary: "bg-secondary/20 text-secondary",
    accent: "bg-accent/20 text-accent",
  };

  return (
    <Card 
      className="group neon-card overflow-visible text-center rounded-md opacity-0 animate-fade-in-up"
      style={{ animationDelay: `${index * 100}ms`, animationFillMode: "forwards" }}
      data-testid={`card-team-${initials.toLowerCase()}`}
    >
      <CardContent className="p-6 space-y-4">
        <div className="relative inline-block">
          <Avatar className="w-20 h-20 mx-auto border-2 border-primary/30 group-hover:border-primary/60 transition-colors">
            <AvatarFallback className={`text-xl font-semibold ${colorClasses[color] || colorClasses.primary}`}>
              {initials}
            </AvatarFallback>
          </Avatar>
          <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-status-online rounded-full border-2 border-background" />
        </div>

        <div>
          <h3 className="font-semibold text-lg group-hover:text-primary transition-colors">
            {name}
          </h3>
          <p className="text-sm text-muted-foreground mt-1">
            {role}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
