interface PageHeaderProps {
  title: string;
  subtitle?: string;
  badge?: string;
}

export default function PageHeader({ title, subtitle, badge }: PageHeaderProps) {
  return (
    <div className="text-center mb-12 pt-24 pb-8">
      {badge && (
        <div className="inline-flex items-center px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6 opacity-0 animate-fade-in-down">
          <span className="text-sm text-primary font-medium">{badge}</span>
        </div>
      )}
      <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 opacity-0 animate-fade-in-up animation-delay-100">
        <span className="gradient-text">{title}</span>
      </h1>
      {subtitle && (
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto opacity-0 animate-fade-in-up animation-delay-200">
          {subtitle}
        </p>
      )}
    </div>
  );
}
