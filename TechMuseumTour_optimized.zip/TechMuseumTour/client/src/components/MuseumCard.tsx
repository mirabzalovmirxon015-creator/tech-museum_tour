import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, ArrowRight, Clock } from "lucide-react";

interface MuseumCardProps {
  id: string;
  name: string;
  location: string;
  country: string;
  description: string;
  image: string;
  founded?: string;
  highlights?: string[];
  index?: number;
}

export default function MuseumCard({
  id,
  name,
  location,
  country,
  description,
  image,
  founded,
  highlights = [],
  index = 0,
}: MuseumCardProps) {
  return (
    <Card 
      className="group neon-card overflow-visible rounded-md opacity-0 animate-fade-in-up"
      style={{ animationDelay: `${index * 150}ms`, animationFillMode: "forwards" }}
      data-testid={`card-museum-${id}`}
    >
      <div className="relative overflow-hidden rounded-t-md">
        <div className="aspect-video">
          <img
            src={image}
            alt={name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
        <Badge 
          className="absolute top-4 right-4 bg-primary/90 text-primary-foreground border-0"
        >
          {country}
        </Badge>
      </div>

      <CardContent className="p-6 space-y-4">
        <div>
          <h3 className="text-xl font-semibold mb-2 group-hover:text-primary transition-colors">
            {name}
          </h3>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <MapPin className="w-4 h-4" />
              <span>{location}</span>
            </div>
            {founded && (
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                <span>с {founded}</span>
              </div>
            )}
          </div>
        </div>

        <p className="text-muted-foreground text-sm line-clamp-3">
          {description}
        </p>

        {highlights.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {highlights.slice(0, 3).map((highlight, i) => (
              <Badge 
                key={i} 
                variant="secondary" 
                className="text-xs"
              >
                {highlight}
              </Badge>
            ))}
          </div>
        )}

        <Link href={`/exhibits?museum=${id}`}>
          <Button 
            className="w-full group/btn mt-2"
            data-testid={`button-museum-details-${id}`}
          >
            Подробнее
            <ArrowRight className="w-4 h-4 ml-2 group-hover/btn:translate-x-1 transition-transform" />
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
