import TeamMemberCard from "../TeamMemberCard";

export default function TeamMemberCardExample() {
  return (
    <div className="max-w-xs">
      <TeamMemberCard
        name="Алексей Иванов"
        role="Руководитель проекта"
        initials="АИ"
        color="primary"
        index={0}
      />
    </div>
  );
}
