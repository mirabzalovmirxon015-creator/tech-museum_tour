import ResourceItem from "../ResourceItem";

export default function ResourceItemExample() {
  return (
    <div className="max-w-lg space-y-4">
      <ResourceItem
        title="Политехнический музей"
        description="Официальный сайт Политехнического музея с информацией о выставках и экспонатах."
        url="https://polymus.ru"
        type="source"
        index={0}
      />
      <ResourceItem
        title="История технических музеев"
        description="Статья об истории развития технических музеев в России и СНГ."
        type="article"
        index={1}
      />
    </div>
  );
}
