import MuseumCard from "../MuseumCard";
import tashkentMuseum from "@assets/generated_images/tashkent_polytechnic_museum_exterior.png";

export default function MuseumCardExample() {
  return (
    <div className="max-w-md">
      <MuseumCard
        id="tashkent"
        name="Ташкентский Политехнический музей"
        location="Ташкент"
        country="Узбекистан"
        description="Крупнейший технический музей Центральной Азии, представляющий историю развития науки и техники региона."
        image={tashkentMuseum}
        founded="1971"
        highlights={["Космос", "Транспорт", "Энергетика"]}
        index={0}
      />
    </div>
  );
}
