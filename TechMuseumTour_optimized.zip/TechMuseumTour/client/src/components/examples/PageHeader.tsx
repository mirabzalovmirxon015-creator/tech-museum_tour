import PageHeader from "../PageHeader";

export default function PageHeaderExample() {
  return (
    <PageHeader
      title="Технические музеи"
      subtitle="Исследуйте богатую историю технических достижений в музеях Узбекистана и России"
      badge="Музеи мира"
    />
  );
}
