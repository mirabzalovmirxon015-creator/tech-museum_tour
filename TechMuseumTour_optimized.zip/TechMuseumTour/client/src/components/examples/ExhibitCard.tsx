import ExhibitCard from "../ExhibitCard";
import locomotiveImage from "@assets/generated_images/steam_locomotive_museum_exhibit.png";

export default function ExhibitCardExample() {
  return (
    <div className="max-w-sm">
      <ExhibitCard
        id="locomotive"
        name="Паровоз серии Ов"
        year="1890-е"
        category="Транспорт"
        description="Один из первых массовых паровозов Российской империи, символ промышленной революции."
        facts={[
          "Производился на Путиловском заводе",
          "Мог развивать скорость до 55 км/ч",
          "Использовался более 50 лет"
        ]}
        image={locomotiveImage}
        museum="Политехнический музей"
        index={0}
      />
    </div>
  );
}
