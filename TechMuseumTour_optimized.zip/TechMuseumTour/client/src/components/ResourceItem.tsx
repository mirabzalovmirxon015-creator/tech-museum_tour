import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, BookOpen, Link2, FileText, Image } from "lucide-react";

interface ResourceItemProps {
  title: string;
  description: string;
  url?: string;
  type: "source" | "article" | "image" | "document";
  index?: number;
}

const typeConfig = {
  source: { icon: BookOpen, label: "Источник", color: "bg-primary/20 text-primary" },
  article: { icon: FileText, label: "Статья", color: "bg-secondary/20 text-secondary" },
  image: { icon: Image, label: "Изображение", color: "bg-accent/20 text-accent" },
  document: { icon: Link2, label: "Документ", color: "bg-chart-4/20 text-chart-4" },
};

export default function ResourceItem({
  title,
  description,
  url,
  type,
  index = 0,
}: ResourceItemProps) {
  const config = typeConfig[type];
  const Icon = config.icon;

  const content = (
    <Card 
      className={`group neon-card overflow-visible rounded-md opacity-0 animate-fade-in-left ${url ? "cursor-pointer" : ""}`}
      style={{ animationDelay: `${index * 75}ms`, animationFillMode: "forwards" }}
      data-testid={`card-resource-${index}`}
    >
      <CardContent className="p-4 flex items-start gap-4">
        <div className={`p-3 rounded-md ${config.color} flex-shrink-0`}>
          <Icon className="w-5 h-5" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-medium group-hover:text-primary transition-colors truncate">
              {title}
            </h3>
            {url && <ExternalLink className="w-4 h-4 text-muted-foreground flex-shrink-0" />}
          </div>
          <p className="text-sm text-muted-foreground line-clamp-2">
            {description}
          </p>
          <Badge variant="secondary" className="mt-2 text-xs">
            {config.label}
          </Badge>
        </div>
      </CardContent>
    </Card>
  );

  if (url) {
    return (
      <a href={url} target="_blank" rel="noopener noreferrer">
        {content}
      </a>
    );
  }

  return content;
}
